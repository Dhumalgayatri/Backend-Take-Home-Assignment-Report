import typer
import csv
from papers.fetcher import fetch_pubmed_ids, fetch_paper_details
from papers.utils import is_non_academic, extract_email
import xml.etree.ElementTree as ET

app = typer.Typer()

@app.command()
def get_papers_list(
    query: str,
    file: str = typer.Option(None, "--file", "-f"),
    debug: bool = typer.Option(False, "--debug", "-d")
):
    ids = fetch_pubmed_ids(query, debug=debug)
    xml_data = fetch_paper_details(ids, debug=debug)

    root = ET.fromstring(xml_data)
    results = []

    for article in root.findall(".//PubmedArticle"):
        pmid = article.findtext(".//PMID")
        title = article.findtext(".//ArticleTitle")
        pub_date = article.findtext(".//PubDate/Year")
        affiliations = article.findall(".//AffiliationInfo")

        company_affiliations = []
        corresponding_email = ""

        for affil in affiliations:
            affil_text = affil.findtext("Affiliation")
            if affil_text and is_non_academic(affil_text):
                company_affiliations.append(affil_text)
                corresponding_email = extract_email(affil_text)

        if company_affiliations:
            results.append({
                "PubmedID": pmid,
                "Title": title,
                "Publication Date": pub_date,
                "Non-academic Author(s)": "",
                "Company Affiliation(s)": "; ".join(company_affiliations),
                "Corresponding Author Email": corresponding_email
            })

    if file:
        with open(file, "w", newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=results[0].keys())
            writer.writeheader()
            writer.writerows(results)
        typer.echo(f"Saved to {file}")
    else:
        for row in results:
            typer.echo(row)

if __name__ == "__main__":
    app()
