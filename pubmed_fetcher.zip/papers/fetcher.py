import requests
from typing import List
from .utils import is_non_academic

BASE_URL = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/"

def fetch_pubmed_ids(query: str, debug=False) -> List[str]:
    params = {
        "db": "pubmed",
        "term": query,
        "retmax": 100,
        "retmode": "json"
    }
    res = requests.get(BASE_URL + "esearch.fcgi", params=params)
    res.raise_for_status()
    ids = res.json()["esearchresult"]["idlist"]
    if debug: print(f"Found IDs: {ids}")
    return ids

def fetch_paper_details(paper_ids: List[str], debug=False) -> str:
    params = {
        "db": "pubmed",
        "id": ",".join(paper_ids),
        "retmode": "xml"
    }
    res = requests.get(BASE_URL + "efetch.fcgi", params=params)
    res.raise_for_status()
    return res.text
