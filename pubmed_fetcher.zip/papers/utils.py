from typing import List

NON_ACADEMIC_KEYWORDS = ['inc', 'ltd', 'pharma', 'biotech', 'corp', 'therapeutics']

def is_non_academic(affiliation: str) -> bool:
    affil = affiliation.lower()
    return any(word in affil for word in NON_ACADEMIC_KEYWORDS)

def extract_email(affiliation: str) -> str:
    import re
    match = re.search(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+", affiliation)
    return match.group(0) if match else ""
