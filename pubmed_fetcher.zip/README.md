# PubMed Paper Fetcher

This CLI fetches research papers from PubMed with at least one author affiliated with pharma/biotech companies.

## 📦 Features
- Search PubMed using full query syntax
- Filters non-academic authors using heuristics
- Outputs to CSV or console
- Command-line interface with `--help`, `--debug`, `--file`

## 📁 Project Structure
- `fetcher.py` – PubMed API logic
- `utils.py` – Heuristics for non-academic detection
- `cli.py` – Command-line interface

## 🚀 Installation

```bash
poetry install
poetry run get-papers-list "cancer AND immunotherapy" -f results.csv
```

## 🔧 Tech Stack
- Python 3.10+
- Poetry
- Typer
- Requests
